//
//  KZSecurityConfiguration.h
//  kidozen.client
//
//  Created by Nicolas Miyasato on 5/29/14.
//  Copyright (c) 2014 Tellago Studios. All rights reserved.
//

#import "KZObject.h"

@interface KZSecurityConfiguration : KZObject



@end
