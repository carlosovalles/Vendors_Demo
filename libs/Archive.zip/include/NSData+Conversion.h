#import <Foundation/Foundation.h>

@interface NSData (Conversion)
#pragma mark - String Conversion
- (NSString *)hexadecimalString;

- (NSString *)KZ_UTF8String;

@end
