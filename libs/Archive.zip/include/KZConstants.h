#import <Foundation/Foundation.h>

@interface KZConstants : NSObject

@end
